﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace practik3
{
    public partial class Form1 : Form
    {
        private RoadNetwork roadNetwork;
        public Form1()
        {
            InitializeComponent();
            roadNetwork = new RoadNetwork();
        }
        private void UpdateRoadList() 
        {
 
            List<Road> roads = roadNetwork.GetRoads(); 

            foreach (Road road in roads.Distinct()) 
            {
                listBox1.Items.Add(road.GetInfo()); 
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {

            string name = NametextBox.Text;
            int width;
            int length;
            int massPerSquareMeter;
            int weatherConditions;
            string input = Console.ReadLine();


            if (!int.TryParse(widthTextBox.Text, out width) || width < 0)
            {
                MessageBox.Show("Вы ввели некорректное значение!", "Ширина", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(lengthTextBox.Text, out length) || width < 0)
            {
                MessageBox.Show("Вы ввели некорректное значение!", "Длина", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(massPerSquareMeterTextBox.Text, out massPerSquareMeter) || width < 0)
            {
                MessageBox.Show("Вы ввели некорректное значение!", "Масса дорожного покрытия", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(weatherConditionsTextBox.Text, out weatherConditions) || width < 0)
            {
                MessageBox.Show("Вы ввели некорректное значение!", "Коэффицент прочности", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            double q = width * length * massPerSquareMeter / 1000;

            double qp;
            if (weatherConditions >= 5 && weatherConditions <= 8)
            {
                qp = q * 1.1;
            }
            else if (weatherConditions == 3 || weatherConditions == 4 || weatherConditions == 9 || weatherConditions == 10)
            {
                qp = q * 1.6;
            }
            else
            {
                qp = 1.9 * q;
            }
            

            // Выводим результаты на экран
            label7.Text = $"Qp трассы под названием {name} = {qp:F2}";

            Road roads = new Road(name, width, length, massPerSquareMeter, weatherConditions, qp); 
            roadNetwork.AddRoad(roads); 
            UpdateRoadList(); 
        }

        private void lengthTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NametextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practik3
{
    internal class Road
    {
        public string Name { get; set; } 
        public int Width { get; set; } 
        public int Length { get; set; } 
        public int MassPerSquareMeter { get; set; } 
        public int WeatherConditions { get; set; }
        public double Qp { get; set; }
        public Road(string name, int width, int length, int massPerSquareMeter, int weatherConditions, double qp)  
        {
            Name = name; 
            Width = width; 
            Length = length;
            MassPerSquareMeter = massPerSquareMeter;
            WeatherConditions = weatherConditions;
            Qp = qp;
        }
        public string GetInfo() //Информация о дороге
        {
            return $"Название дороги - {Name}.  " +
                $"Ширина дороги: {Width}.  " +
                $"Длина дороги: {Length}. " +
                $"Масса дорожного покрытия: {MassPerSquareMeter}." +
                $"Коэффициент прочности в зависимости от погодных условий: {WeatherConditions}." +
                $"Qp: {Qp}";
        }
    }
}

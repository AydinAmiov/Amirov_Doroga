﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practik3
{
    internal class RoadNetwork
    {
        private List<Road> roads;
        private Dictionary<string, Road> roadsByName;


        public RoadNetwork() //Конструктор
        {
        roads = new List<Road>(); //Создаёт список с элементами типа 'Shop'
        roadsByName = new Dictionary<string, Road>(); //Создаёт словарь, где ключ: 'string' тип: 'Shop'. Используется для быстрого доступа к магазинам по их имени.
        }

        public void AddRoad(Road road) //Добавляет магазин
        {
            roads.Add(road);
            roadsByName.Add(road.Name, road);
        }
        public void RemoveShop(Road road) 
        {
            roads.Remove(road);
            roadsByName.Remove(road.Name);
        }
        public List<Road> GetRoads() //Возвращает список всех магазинов, хранящихся в объекте класса 
        {
            return roads;
        }
        public Road GetRoadByName(string name) //Возвращает магазин по заданному имени из списка магазинов "ListBox"
        {
            return roads.FirstOrDefault(shop => string.Equals(shop.Name, name, StringComparison.OrdinalIgnoreCase));
        }
    }
    
}
